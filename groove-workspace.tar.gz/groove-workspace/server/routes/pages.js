/**
 * routes/pages.js
 *
 * Import FedWiki pages from any FedWiki server.
 * FedWiki's JSON API: GET {host}/{slug}.json returns the page object.
 * Export returns the raw FedWiki JSON so pages can be forked back to any wiki.
 */

const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const { FedWikiPageDB } = require('../db/fedwiki-page');

let _dataDir = './server/data';
function setDataDir(d) { _dataDir = d; }

function getDb() {
  return new FedWikiPageDB(_dataDir);
}

// Import a page from a FedWiki URL
// e.g. POST { url: "http://ward.dojo.fed.wiki/welcome-visitors" }
router.post('/import', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'url required' });

    const parsed = new URL(url);
    const slug = parsed.pathname.replace(/^\//, '').replace(/\.json$/, '');
    const jsonUrl = `${parsed.protocol}//${parsed.host}/${slug}.json`;

    const response = await fetch(jsonUrl, {
      headers: { Accept: 'application/json' },
      timeout: 10000,
    });

    if (!response.ok) {
      return res.status(502).json({ error: `FedWiki returned ${response.status}` });
    }

    const pageJson = await response.json();
    const title = pageJson.title || slug;
    const db = getDb();
    const pageId = db.upsertPage(url, title, slug, pageJson);

    res.json({ pageId, title, slug });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// List all imported pages
router.get('/', (req, res) => {
  const pages = getDb().listPages();
  res.json({ pages });
});

// Get a specific page
router.get('/:id', (req, res) => {
  const page = getDb().getPage(req.params.id);
  if (!page) return res.status(404).json({ error: 'Not found' });
  res.json({ page });
});

// Export a page as FedWiki JSON (for forking back to a wiki)
router.get('/:id/export', (req, res) => {
  const page = getDb().getPage(req.params.id);
  if (!page) return res.status(404).json({ error: 'Not found' });
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="${page.slug || page.id}.json"`);
  res.json(page.raw_json);
});

// Delete a page
router.delete('/:id', (req, res) => {
  getDb().deletePage(req.params.id);
  res.json({ ok: true });
});

module.exports = { router, setDataDir };
