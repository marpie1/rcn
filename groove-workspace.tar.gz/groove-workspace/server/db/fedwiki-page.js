const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { openDb } = require('./sqldb');

class FedWikiPageDB {
  constructor(dataDir = './server/data') {
    this.db = openDb(path.join(dataDir, 'fedwiki-pages.db'));
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS pages (
        id TEXT PRIMARY KEY, title TEXT NOT NULL, source_url TEXT,
        slug TEXT, raw_json TEXT NOT NULL, imported_at INTEGER NOT NULL, updated_at INTEGER
      );
    `);
  }
  upsertPage(sourceUrl, title, slug, rawJson) {
    const existing = this.db.get('SELECT id FROM pages WHERE source_url=?', [sourceUrl]);
    if (existing) {
      this.db.run(`UPDATE pages SET title=?,raw_json=?,updated_at=? WHERE id=?`,
        [title, JSON.stringify(rawJson), Date.now(), existing.id]);
      return existing.id;
    } else {
      const id = uuidv4();
      this.db.run(`INSERT INTO pages (id,title,source_url,slug,raw_json,imported_at) VALUES (?,?,?,?,?,?)`,
        [id, title, sourceUrl, slug, JSON.stringify(rawJson), Date.now()]);
      return id;
    }
  }
  getPage(id) {
    const row = this.db.get('SELECT * FROM pages WHERE id=?', [id]);
    if (!row) return null;
    return { ...row, raw_json: JSON.parse(row.raw_json) };
  }
  listPages() {
    return this.db.all('SELECT id,title,source_url,slug,imported_at,updated_at FROM pages ORDER BY imported_at DESC');
  }
  deletePage(id) { this.db.run('DELETE FROM pages WHERE id=?', [id]); }
}

module.exports = { FedWikiPageDB };
