/**
 * page-viewer.js
 * Renders a FedWiki page from its stored JSON.
 */

const PageViewer = {
  currentPageId: null,

  async display(pageId) {
    this.currentPageId = pageId;
    const view = document.getElementById('page-view');
    const discussion = document.getElementById('discussion-view');
    const welcome = document.getElementById('welcome');

    welcome.classList.add('hidden');
    discussion.classList.add('hidden');
    view.classList.remove('hidden');
    view.innerHTML = '<div class="loading">Loading page…</div>';

    try {
      const { page } = await API.getPage(pageId);
      view.innerHTML = this.render(page);
    } catch (err) {
      view.innerHTML = `<div class="error-msg">Failed to load page: ${err.message}</div>`;
    }
  },

  render(page) {
    const json = page.raw_json;
    const story = json.story || [];

    const items = story.map(item => this.renderItem(item)).join('');

    return `
      <div class="page-container">
        <div class="page-header">
          <div>
            <h2>${this.escape(json.title || page.title)}</h2>
            <div class="source-url">${this.escape(page.source_url || '')}</div>
          </div>
          <a href="${API.exportPageUrl(page.id)}" class="export-btn" download>Export JSON</a>
        </div>
        <div class="page-story">${items}</div>
      </div>
    `;
  },

  renderItem(item) {
    if (!item) return '';
    switch (item.type) {
      case 'paragraph':
        return `<div class="fedwiki-paragraph">${this.linkify(this.escape(item.text || ''))}</div>`;
      case 'markdown':
        return `<div class="fedwiki-item">${this.escape(item.text || '')}</div>`;
      case 'html':
        return `<div class="fedwiki-item">${item.text || ''}</div>`;
      case 'image':
        return `<div class="fedwiki-item"><img src="${this.escape(item.url || '')}" alt="${this.escape(item.caption || '')}" style="max-width:100%"></div>`;
      case 'reference':
        return `<div class="fedwiki-item" style="border-left:3px solid #5b6af0;padding-left:12px">
          <strong>→ ${this.escape(item.title || '')}</strong><br>
          <small style="color:#6b7280">${this.escape(item.site || '')}</small>
        </div>`;
      default:
        if (item.text) return `<div class="fedwiki-item">${this.escape(item.text)}</div>`;
        return '';
    }
  },

  linkify(text) {
    // FedWiki [[Double Bracket]] links
    return text.replace(/\[\[(.+?)\]\]/g, '<span style="color:#5b6af0;cursor:pointer">$1</span>');
  },

  escape(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
};

window.PageViewer = PageViewer;
