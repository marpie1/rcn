/**
 * discussion-ui.js
 * Renders threaded discussions with reply support.
 * Messages written by someone other than the person of record are
 * prominently marked (written_by_other flag).
 */

const DiscussionUI = {
  currentDiscussionId: null,
  replyingToId: null,
  replyingToAuthor: null,
  pollInterval: null,

  async display(discussionId, discussionName) {
    this.currentDiscussionId = discussionId;
    this.replyingToId = null;

    const view = document.getElementById('discussion-view');
    const page = document.getElementById('page-view');
    const welcome = document.getElementById('welcome');

    welcome.classList.add('hidden');
    page.classList.add('hidden');
    view.classList.remove('hidden');

    view.innerHTML = `
      <div class="discussion-container">
        <div class="discussion-header">
          <h2>${this.escape(discussionName || 'Discussion')}</h2>
        </div>
        <div class="messages-area" id="messages-area">
          <div class="loading">Loading messages…</div>
        </div>
        <div class="compose-area" id="compose-area">
          <div id="replying-to-banner" class="replying-to-banner hidden"></div>
          <textarea id="compose-text" placeholder="Write a message…"></textarea>
          <div class="compose-actions">
            <label>
              <input type="checkbox" id="written-by-other-check">
              Entry by someone else
            </label>
            <button class="send-btn" id="send-btn">Send</button>
          </div>
        </div>
      </div>
    `;

    document.getElementById('send-btn').addEventListener('click', () => this.sendMessage());
    document.getElementById('compose-text').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) this.sendMessage();
    });

    await this.loadMessages();

    // Poll for new messages every 5s
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = setInterval(() => this.loadMessages(), 5000);
  },

  async loadMessages() {
    const area = document.getElementById('messages-area');
    if (!area) return;
    try {
      const { messages } = await API.getMessages(this.currentDiscussionId);
      const scrolledToBottom = area.scrollHeight - area.clientHeight <= area.scrollTop + 40;
      area.innerHTML = this.renderThread(messages, null);
      if (scrolledToBottom) area.scrollTop = area.scrollHeight;
    } catch (err) {
      area.innerHTML = `<div class="error-msg">${err.message}</div>`;
    }
  },

  renderThread(messages, parentId) {
    const children = messages.filter(m => (m.parent_id || null) === parentId);
    if (!children.length) return parentId ? '' : '<div class="loading" style="padding:40px">No messages yet. Start the discussion.</div>';

    return children.map(m => {
      const replies = this.renderThread(messages, m.id);
      const replyBlock = replies ? `<div class="message-replies">${replies}</div>` : '';
      const otherBadge = m.written_by_other ? '<span class="other-badge">Entered by other</span>' : '';
      const refs = (m.pageReferences || []).map(r =>
        `<span class="page-ref-tag" onclick="PageViewer.display('${r.page_id}')">📄 ${this.escape(r.page_title || r.page_id)}</span>`
      ).join(' ');

      return `
        <div class="message ${m.written_by_other ? 'written-by-other' : ''}">
          <div class="message-meta">
            <span class="message-author">${this.escape(m.author_name)}</span>
            ${otherBadge}
            <span> · ${this.formatTime(m.created_at)}</span>
          </div>
          <div class="message-content">${this.escape(m.content)}</div>
          ${refs}
          <button class="reply-btn" onclick="DiscussionUI.setReplyTo('${m.id}', '${this.escape(m.author_name)}')">Reply</button>
          ${replyBlock}
        </div>
      `;
    }).join('');
  },

  setReplyTo(messageId, authorName) {
    this.replyingToId = messageId;
    this.replyingToAuthor = authorName;
    const banner = document.getElementById('replying-to-banner');
    if (banner) {
      banner.classList.remove('hidden');
      banner.innerHTML = `Replying to <strong>${this.escape(authorName)}</strong> <button onclick="DiscussionUI.clearReplyTo()">✕</button>`;
    }
    document.getElementById('compose-text').focus();
  },

  clearReplyTo() {
    this.replyingToId = null;
    this.replyingToAuthor = null;
    const banner = document.getElementById('replying-to-banner');
    if (banner) banner.classList.add('hidden');
  },

  async sendMessage() {
    const textarea = document.getElementById('compose-text');
    const content = textarea.value.trim();
    if (!content) return;

    const writtenByOther = document.getElementById('written-by-other-check').checked;
    const identity = IdentityUI.current;

    try {
      await API.postMessage(this.currentDiscussionId, {
        authorId: identity ? identity.id : 'anonymous',
        authorName: identity ? identity.displayName : 'Anonymous',
        content,
        parentId: this.replyingToId,
        pageReferences: [],
        writtenByOther,
      });
      textarea.value = '';
      document.getElementById('written-by-other-check').checked = false;
      this.clearReplyTo();
      await this.loadMessages();
    } catch (err) {
      alert('Failed to send: ' + err.message);
    }
  },

  formatTime(ts) {
    const d = new Date(ts);
    return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  },

  escape(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
};

window.DiscussionUI = DiscussionUI;
