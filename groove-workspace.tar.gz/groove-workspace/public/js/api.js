/**
 * api.js — thin fetch wrapper for all server endpoints
 */

const API = {
  base: '',

  async post(path, body) {
    const r = await fetch(this.base + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({ error: r.statusText }));
      throw new Error(err.error || r.statusText);
    }
    return r.json();
  },

  async get(path) {
    const r = await fetch(this.base + path);
    if (!r.ok) {
      const err = await r.json().catch(() => ({ error: r.statusText }));
      throw new Error(err.error || r.statusText);
    }
    return r.json();
  },

  async del(path) {
    const r = await fetch(this.base + path, { method: 'DELETE' });
    if (!r.ok) throw new Error(r.statusText);
    return r.json();
  },

  // Identity
  createIdentity: (displayName) => API.post('/api/identity/generate', { displayName }),
  getIdentity: (id) => API.get(`/api/identity/${id}`),
  grantAccess: (body) => API.post('/api/identity/grant', body),
  revokeGrant: (grantId) => API.post(`/api/identity/revoke/${grantId}`, {}),
  getGrants: (workspaceId) => API.get(`/api/identity/grants/${workspaceId}`),
  getAccessLog: (workspaceId) => API.get(`/api/identity/log/${workspaceId}`),

  // Pages
  importPage: (url) => API.post('/api/pages/import', { url }),
  listPages: () => API.get('/api/pages'),
  getPage: (id) => API.get(`/api/pages/${id}`),
  deletePage: (id) => API.del(`/api/pages/${id}`),
  exportPageUrl: (id) => `/api/pages/${id}/export`,

  // Discussions
  createDiscussion: (name, workspaceId, createdBy) =>
    API.post('/api/discussions', { name, workspaceId, createdBy }),
  listDiscussions: (workspaceId) =>
    API.get(workspaceId ? `/api/discussions?workspaceId=${workspaceId}` : '/api/discussions'),
  getMessages: (id) => API.get(`/api/discussions/${id}/messages`),
  postMessage: (id, body) => API.post(`/api/discussions/${id}/messages`, body),
};

window.API = API;
